2018-05-20 last updated

Dataset created by:
Thomas Padilla & Brandon Locke

This dataset consists of the first 9 novels, listed in alphabetically by author last name in the British Women Romantic Poets Collection from University of California Davis. 

Collection name:
British Women Romantic Poets, 1789-1832 | University of California, Davis

URL:
http://digital.lib.ucdavis.edu/projects/bwrp/Works/


This also includes page images from _The seven ages of woman and other poems_
Author: Agnes Strickland

Collection Name: Kohler Collection of British Poetry | University of California Libraries 

URL: Accessed via Internet Archive - https://archive.org/details/sevenagesofwoman00stririch

